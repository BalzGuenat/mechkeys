# Source Files

### Compilation
To compile the source files, enter the `keyboard` directory and run `make`, which will generate a `firmware.hex` file.

### Notes
This contains a slightly modified version of the TMK keyboard firmware. Most official instructions will apply, but there will be some differences.
